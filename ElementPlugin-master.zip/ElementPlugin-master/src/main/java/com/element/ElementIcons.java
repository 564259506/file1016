package com.element;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

public class ElementIcons {
    public static final Icon FILE = IconLoader.getIcon("/icons/element.png");
}
